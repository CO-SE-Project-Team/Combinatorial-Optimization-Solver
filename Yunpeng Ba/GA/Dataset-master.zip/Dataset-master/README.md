# Dataset Archive

- TSPLIB: .tsp files for TSP problems, More details on [OmegaXYZ-LIBTSP](https://www.omegaxyz.com/2018/12/03/tsplib-matlab/).
- citys_data.mat: Data for ACO algorithm, More details on [OmegaXYZ-ACOTSP](https://www.omegaxyz.com/2018/07/10/aco-tsp/).
- Parkinson.mat: Data for feature selection.
- DLBCL.mat: Data for feature selection.
- Converter: Code to transform data format among .mat, .txt and .arff.

